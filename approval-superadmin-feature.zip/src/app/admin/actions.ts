"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Dipanggil di awal tiap action buat mastiin yang manggil action ini
 * beneran super admin — pengecekan kedua selain gate di layout.tsx,
 * biar aman walau action-nya suatu saat dipanggil dari tempat lain.
 */
async function assertSuperAdmin() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Belum login.");

  const { data: adminRow } = await supabase
    .from("platform_admins")
    .select("id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (!adminRow) throw new Error("Bukan super admin.");
}

export async function approveCompany(companyId: string) {
  await assertSuperAdmin();
  const admin = createAdminClient() as any;

  const { error } = await admin
    .from("companies")
    .update({ status: "approved" })
    .eq("id", companyId);

  if (error) throw new Error(error.message);
  revalidatePath("/admin");
}

export async function rejectCompany(companyId: string) {
  await assertSuperAdmin();
  const admin = createAdminClient() as any;

  const { error } = await admin
    .from("companies")
    .update({ status: "rejected" })
    .eq("id", companyId);

  if (error) throw new Error(error.message);
  revalidatePath("/admin");
}
