"use client";

import { useMemo, useState, useTransition } from "react";
import { approveCompany, rejectCompany } from "@/app/admin/actions";

type Company = {
  id: string;
  name: string;
  slug: string;
  status: "pending" | "approved" | "rejected";
  created_at: string;
  company_users: { count: number }[];
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

const statusConfig = {
  pending: { label: "Menunggu", cls: "badge-warning" },
  approved: { label: "Aktif", cls: "badge-success" },
  rejected: { label: "Ditolak", cls: "badge-danger" },
};

export function AdminClient({ companies }: { companies: Company[] }) {
  const [tab, setTab] = useState<"pending" | "approved" | "rejected" | "all">(
    "pending",
  );
  const [isPending, startTransition] = useTransition();

  const filtered = useMemo(() => {
    if (tab === "all") return companies;
    return companies.filter((c) => c.status === tab);
  }, [companies, tab]);

  const counts = useMemo(
    () => ({
      pending: companies.filter((c) => c.status === "pending").length,
      approved: companies.filter((c) => c.status === "approved").length,
      rejected: companies.filter((c) => c.status === "rejected").length,
      all: companies.length,
    }),
    [companies],
  );

  function handleApprove(id: string) {
    startTransition(() => {
      approveCompany(id);
    });
  }

  function handleReject(id: string) {
    if (!confirm("Tolak pendaftaran restoran ini?")) return;
    startTransition(() => {
      rejectCompany(id);
    });
  }

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-ink">Kelola Restoran</h1>
        <p className="text-sm text-ink-muted">
          {companies.length} restoran terdaftar di seluruh platform
        </p>
      </div>

      <div className="mb-5 flex flex-wrap gap-2">
        {(
          [
            { key: "pending" as const, label: "Menunggu" },
            { key: "approved" as const, label: "Aktif" },
            { key: "rejected" as const, label: "Ditolak" },
            { key: "all" as const, label: "Semua" },
          ]
        ).map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${
              tab === t.key
                ? "border-accent bg-accent text-white"
                : "border-surface-border bg-surface-card text-ink-muted"
            }`}
          >
            {t.label} ({counts[t.key]})
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card p-10 text-center text-sm text-ink-muted">
          Gak ada restoran di kategori ini.
        </div>
      ) : (
        <div className="card overflow-hidden">
          {filtered.map((c, i) => {
            const cfg = statusConfig[c.status];
            return (
              <div
                key={c.id}
                className={`flex flex-wrap items-center justify-between gap-3 px-4 py-3.5 ${
                  i !== 0 ? "border-t border-surface-border" : ""
                }`}
              >
                <div>
                  <p className="text-sm font-semibold text-ink">{c.name}</p>
                  <p className="text-xs text-ink-muted">
                    /{c.slug} &middot; {c.company_users?.[0]?.count ?? 0} user
                    &middot; daftar {formatDate(c.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={cfg.cls}>{cfg.label}</span>
                  {c.status === "pending" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleApprove(c.id)}
                        disabled={isPending}
                        className="rounded-lg bg-accent px-3 py-1.5 text-xs font-semibold text-white"
                      >
                        Setujui
                      </button>
                      <button
                        onClick={() => handleReject(c.id)}
                        disabled={isPending}
                        className="rounded-lg border border-surface-border px-3 py-1.5 text-xs font-semibold text-ink-muted"
                      >
                        Tolak
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
