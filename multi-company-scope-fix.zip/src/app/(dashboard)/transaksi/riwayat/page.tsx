import { createClient } from "@/lib/supabase/server";
import { getActiveCompanyId } from "@/lib/get-active-company";
import { RiwayatClient } from "@/components/transaksi/RiwayatClient";

export default async function RiwayatPage() {
  const supabase = (await createClient()) as any;
  const companyId = await getActiveCompanyId();

  const { data: orders } = await supabase
    .from("orders")
    .select(
      "id, total, subtotal, tax, paid_at, restaurant_tables(name), order_items(count)",
    )
    .eq("company_id", companyId)
    .eq("status", "paid")
    .order("paid_at", { ascending: false });

  return <RiwayatClient orders={orders ?? []} />;
}
