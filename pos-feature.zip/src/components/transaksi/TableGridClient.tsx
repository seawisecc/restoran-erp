"use client";

import { useTransition } from "react";
import { openOrCreateOrder } from "@/app/(dashboard)/transaksi/actions";

type Table = { id: string; name: string; seats: number };
type OpenOrder = { id: string; table_id: string | null; created_at: string };

function timeAgo(iso: string) {
  const mins = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 60) return `${mins} menit lalu`;
  return `${Math.round(mins / 60)} jam lalu`;
}

export function TableGridClient({
  tables,
  openOrders,
}: {
  tables: Table[];
  openOrders: OpenOrder[];
}) {
  const [isPending, startTransition] = useTransition();

  function handleClick(tableId: string) {
    startTransition(() => {
      openOrCreateOrder(tableId);
    });
  }

  const orderByTable = new Map(openOrders.map((o) => [o.table_id, o]));

  return (
    <div className="-m-4 min-h-[calc(100vh-64px)] bg-accent p-6 md:-m-6 md:p-8">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Pilih Meja</h2>
          <p className="text-sm text-sidebar-muted">
            {tables.length} meja &middot; {openOrders.length} sedang terisi
          </p>
        </div>
        <div className="flex gap-4 text-xs text-sidebar-muted">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-sidebar-hover" /> Kosong
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-accent-warning" /> Terisi
          </span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3.5 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6">
        {tables.map((t) => {
          const order = orderByTable.get(t.id);
          const occupied = Boolean(order);
          return (
            <button
              key={t.id}
              disabled={isPending}
              onClick={() => handleClick(t.id)}
              className={`flex aspect-square flex-col items-center justify-center gap-1 rounded-2xl font-bold transition-opacity disabled:opacity-60 ${
                occupied
                  ? "bg-accent-warningBg text-accent-warning"
                  : "bg-sidebar-hover text-sidebar-foreground"
              }`}
            >
              <span className="text-xl">{t.name}</span>
              <span className="text-[10px] font-medium opacity-80">
                {occupied ? timeAgo(order!.created_at) : `${t.seats} kursi`}
              </span>
            </button>
          );
        })}
      </div>

      {tables.length === 0 && (
        <div className="rounded-2xl bg-sidebar-hover p-10 text-center text-sm text-sidebar-muted">
          Belum ada meja terdaftar. Tambahkan lewat Supabase SQL Editor
          atau menu Pengaturan (segera hadir).
        </div>
      )}
    </div>
  );
}
